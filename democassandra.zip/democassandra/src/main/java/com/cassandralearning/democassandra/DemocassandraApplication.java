package com.cassandralearning.democassandra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemocassandraApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemocassandraApplication.class, args);
	}

}
